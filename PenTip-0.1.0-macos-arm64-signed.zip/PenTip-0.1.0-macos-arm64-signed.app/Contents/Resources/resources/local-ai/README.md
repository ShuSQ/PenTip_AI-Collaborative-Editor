Bundled Local AI Assets

This project now uses a hybrid setup:
- Bundle a small local inference engine binary.
- Download the large model file on first use.

Required bundled asset:
- `bin/llama-cli` (or `bin/llama-cli-macos`)
- all dependent `bin/lib*.dylib` files shipped with the same llama.cpp release

Model runtime path (auto-downloaded on first use):
- `$APP_DATA_DIR/local-ai/models/qwen2.5-3b-instruct-q4_k_m.gguf`

Optional Gemma 4 runtime paths:
- `$APP_DATA_DIR/local-ai/models/google_gemma-4-E2B-it-Q4_K_M.gguf`
- `$APP_DATA_DIR/local-ai/models/google_gemma-4-E4B-it-Q4_K_M.gguf`

After engine file is present, run:
- `npm run tauri build`
